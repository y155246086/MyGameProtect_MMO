/**
 * 
 */

import java.util.LinkedList;
import java.util.List;


/**
 * 移动控制类
 * @author wangguohao
 * 2017-4-21 下午4:48:14
 */
public class MoveController {
	
	private Player owner; 
	/**
	 * 移动路径
	 */
	private final LinkedList<float[]> pathQueue = new LinkedList<float[]>();
	
	/**
	 * 上次更新位置是什么时候
	 */
	protected volatile long lastUpdatePos;
	protected volatile long lastUpdateDir;
	
	//FIXME  
	private float reducedistance;
	
	//是否在移动
	protected volatile boolean moving = false;
	//移动速度
	protected long movespeed = 100;
	
	public MoveController(Player player) {
		this.owner = player;
	}
	/**
	 * 初始化移动数据，并开始移动到第一个点
	 */
	public void setMovePath(List<float[]> paths, long startTime) {
		reducedistance=0;
		this.lastUpdatePos = startTime;//在玩家狂点鼠标的时候回导致整个值频繁被设置，在moveByTime里宠物无法行走
		lastUpdateDir = startTime;
		this.pathQueue.clear();
		this.pathQueue.addAll(paths);
		moving = true;
	}
	
	/**
	 * 按时间移动
	 * FIXME  移动相关参数未调试，根据项目来具体调整
	 * @param now 当前时间
	 */
	public void moveByTime(long now) {
		final long dur = now - lastUpdatePos;
		if (dur == 0) {
			return;
		}
		//最大移动时间
		float maxDistance = dur * movespeed / 1000 + reducedistance;
		//两点之间的距离
		float dis = 0;
		//是否更新了
		boolean isUpdated = false;
		// peek() 方法检索，但是不移除此列表的头元素(第一个元素)。
		for (float[] pos = pathQueue.peek(); pos != null;) {
			//获取当前位置
			float[] curPos = owner.getCurPos();
			//判断精灵当前点和路径点之间的距离
			dis = DistanceFormula.getDistance(curPos,pos);
			if (maxDistance <= 0 || dis<=0) {
				if(pos[0]==curPos[0] && pos[1]==curPos[1] && pos[2]==curPos[2]){
					pathQueue.poll();
				}
				break;
			}
			
			//长度判断
			float percent = maxDistance / dis;
			if(percent>1){
				owner.moveTo(pos);
				pathQueue.poll();
				isUpdated = true;
				break;
			}else{
				if(percent > 0.01f){
					float[] midpoint = DistanceFormula.getPointByPencent(curPos,pos,percent);
					if(!DistanceFormula.isEqual(owner.getCurPos(), midpoint)){
						reducedistance = maxDistance - DistanceFormula.getDistance(midpoint,curPos);
						owner.moveTo(midpoint);
						isUpdated = true;
					}
				}
				break;
			}
		}
		if (isUpdated) {
			this.lastUpdatePos = now;
		}
	}
}
