
public class Player {
	private float[] curPos;


	/**
	 * 精灵移动
	 */
	public void moveTo(float[] toPos) {
		this.curPos = toPos;
		StringBuilder sb = new StringBuilder();
		for(float p : toPos) {
			sb.append(" 点："+p);
		}
		//通知到客户端
		//sendMessage
	}

	public float[] getCurPos() {
		return curPos;
	}

	public void setCurPos(float[] curPos) {
		this.curPos = curPos;
	}
	
}
