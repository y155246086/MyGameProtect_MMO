/**
 * 
 */

/**
 * 距离判断
 * @author wangguohao
 * 2017-4-21 下午5:10:43
 */
public class DistanceFormula {

	/**
	 *三维坐标系中 两点间的距离公式
	 */
	public static float getDistance(float[] start,float[] end) {
		return (float) ((Math.pow(start[0]-end[0], 2)+Math.pow(start[1]-end[1], 2)+Math.pow(start[2]-end[2], 2))/2);
	}
	
	/**
	 * 从(srcX,srcY)为起点，（destX,destY)为终点，求出两点中间一点， 该点到起点的距离，占两点直线距离的百分比为percent
	 * 
	 * @param srcX
	 * @param srcY
	 * @param destX
	 * @param destY
	 * @param percent
	 * @return
	 */
	public static float[] getPointByPencent(float[] start, float[] end, float percent) {
		return new float[]{start[0]+(end[0] - start[0]) * percent,
				start[1]+(end[1] - start[1]) * percent,
				start[2]+(end[2] - start[2]) * percent};
	}
	
	public static boolean isEqual(float[] start, float[] end) {
		return start[0]==end[0] && start[1]==end[1] && start[2]==end[2];
	}
}
